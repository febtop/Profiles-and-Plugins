# Optimus-Cura-CNC-plugin
Plugin for Cura to connect wirelessly from your computer, to the Optimus and set it up for CNC jobs.
